This release includes FOTA update from mfw_nrf9160_1.3.2 release to mfw_nrf9160_1.3.4 release.
FOTA update filename is mfw_nrf9160_update_from_1.3.2_to_1.3.4.bin.

This release includes FOTA update from mfw_nrf9160_1.3.3 release to mfw_nrf9160_1.3.4 release.
FOTA update filename is mfw_nrf9160_update_from_1.3.3_to_1.3.4.bin.

Non-wired full modem update can be performed by using new MFW CBOR image format and suitable support from the nRF Connect SDK and device hardware.

This release includes FOTA-TEST images between mfw_nrf9160_1.3.4 release and mfw_nrf9160_1.3.4-FOTA-TEST image.
FOTA test update filenames are mfw_nrf9160_update_from_1.3.4_to_1.3.4-FOTA-TEST and mfw_nrf9160_update_from_1.3.4-FOTA-TEST_to_1.3.4.

UUID of mfw_nrf9160_1.3.4 is f6e3bd7b-7df3-4b88-b43a-a7a9766a04ad
UUID of mfw_nrf9160_1.3.4-FOTA-TEST is ec4458cc-1df7-41b1-9bee-729ccc5d5d02