This release includes FOTA update from mfw_nrf9160_1.3.5 release to mfw_nrf9160_1.3.6 release.
FOTA update filename is mfw_nrf9160_update_from_1.3.5_to_1.3.6.bin.

Non-wired full modem update can be performed by using new MFW CBOR image format and suitable support from the nRF Connect SDK and device hardware.

This release includes FOTA-TEST images between mfw_nrf9160_1.3.6 release and mfw_nrf9160_1.3.6-FOTA-TEST image.
FOTA test update filenames are mfw_nrf9160_update_from_1.3.6_to_1.3.6-FOTA-TEST and mfw_nrf9160_update_from_1.3.6-FOTA-TEST_to_1.3.6.

UUID of mfw_nrf9160_1.3.6 is 3e926f75-d31b-4852-b394-8c13f5a8bb6e
UUID of mfw_nrf9160_1.3.6-FOTA-TEST is bd4c354c-f3bc-4243-9f3d-c5f26020427c